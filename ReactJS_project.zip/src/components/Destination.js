import Athens1 from "../assets/19.webp";
import Athens2 from "../assets/20.jpg";
import Santorini1 from "../assets/21.jpg";
import Santorini2 from "../assets/22.jpg";
import "./DestinationStyles.css";
import DestinationData from "./DestinationData";

const Destination = () => {
  return (
    <div className="destination">
      <h1>Popular Destinations</h1>
      <p>Tours give you the opportunity to explore</p>
      <DestinationData
        className="first-des"
        heading="Athens, Greece"
        text="Athens is Europe's historic capital and is the cradle of democracy,
        the arts, the sciences, and western philosophy. The expansive city's
        modern urban landscape, which stands in the shadow of the Parthenon,
        reflects its fascinating past, its multi-cultural current
        personality, as well as the infrastructure and facilities.The ideal
        Mediterranean climate with the fabled Greek sun, the rare fusion of
        glorious history with contemporary urban innovation, the coexistence
        of great culture with breathtaking natural beauty, the high standard
        of hotel accommodations, modern modes of transportation like the
        cutting-edge modern metro, the vibrant pace of life, the abundance
        of opportunities for shopping, dining, and nightlife, and of course
        the friendliness of the Athenians people, are all characteristics of
        Athens."
        img1={Athens1}
        img2={Athens2}
      />

      <DestinationData
        className="first-des-reverse"
        heading="Santorini, Greece"
        text="One of the most well-known islands in the world is Santorini, often referred to as Thira in ancient times. It is priceless to be able to enjoy local cuisine, a beverage, or coffee while sitting in front of the caldera and taking in the breathtaking grandeur of an active volcano.The island is actually a collection of islands in the southernmost region of the Cyclades, including Thira, Thirassia, Aspronissi, Palea, and Nea Kameni.
        One of the few active volcanoes on Greek and European soil is the one in Santorini. Santorini's islands were formed as a result of intense volcanic activity; twelve massive eruptions, one roughly every 20,000 years, resulted in the collapse of the volcano's central portion, leaving a sizable crater."
        img1={Santorini1}
        img2={Santorini2}
      />
    </div>
  );
};

export default Destination;
