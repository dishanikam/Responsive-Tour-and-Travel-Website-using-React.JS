import Athens1 from "../assets/19.webp";
import Athens2 from "../assets/20.jpg";
import Santorini1 from "../assets/21.jpg";
import Santorini2 from "../assets/22.jpg";
import { Component } from "react";
import "./DestinationStyles.css";

class DestinationData extends Component {
  render() {
    return (
      <div className={this.props.className}>
        <div className="des-text">
          <h2>{this.props.heading}</h2>
          <p>{this.props.text}</p>
        </div>
        <div className="image">
          <img alt="img" src={this.props.img1} />
          <img alt="img" src={this.props.img2} />
        </div>
      </div>
    );
  }
}

export default DestinationData;
