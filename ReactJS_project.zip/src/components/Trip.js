import TripData from "./TripData";
import "./TripStyles.css";
import Trip1 from "../assets/23.jpg";
import Trip2 from "../assets/24.jpeg";
import Trip3 from "../assets/26.jpg";

function Trip() {
  return (
    <div>
      <h1>Recent Trips</h1>
      <p>Discover unique destinations using Google Maps</p>
      <div className="tripcard">
        <TripData
          image={Trip1}
          heading="Trip in France"
          text="France, officially French Republic, French France or République Française, country of northwestern Europe. Historically and culturally among the most important nations in the Western world, France has also played a highly significant role in international affairs, with former colonies in every corner of the globe. Bounded by the Atlantic Ocean and the Mediterranean Sea, the Alps and the Pyrenees, France has long provided a geographic, economic, and linguistic bridge joining northern and southern Europe. It is Europe’s most important agricultural producer and one of the world’s leading industrial powers."
        />
        <TripData
          image={Trip2}
          heading="Trip in India"
          text="India, country that occupies the greater part of South Asia. Its capital is New Delhi, built in the 20th century just south of the historic hub of Old Delhi to serve as India’s administrative centre. Its government is a constitutional republic that represents a highly diverse population consisting of thousands of ethnic groups and likely hundreds of languages. Architecture is perhaps India’s greatest glory. Among the most-renowned monuments are many cave temples hewn from rock (of which those at Ajanta and Ellora are most noteworthy); the Sun Temple at Konarak (Konarka); the vast temple complexes at Bhubaneshwar, Khajuraho, and Kanchipuram (Conjeeveram); such Mughal masterpieces as Humayun’s tomb and the Taj Mahal; and, from the 20th century, buildings such as the High Court in the planned city of Chandigarh, designed by the Swiss-born architect Le Corbusier, and the Bhopal State Assembly building in Bhopal, Madhya Pradesh, designed by the Indian architect and urban planner Charles Correa. Also notable are stepwells, such as the Rani ki Vav (“Queen’s Stepwell”) in Patan (northern Gujarat), now a UNESCO World Heritage site. "
        />
        <TripData
          image={Trip3}
          heading="Trip in Maldives"
          text="Maldives, in full Republic of Maldives, also called Maldive Islands, independent island country in the north-central Indian Ocean. It consists of a chain of about 1,200 small coral islands and sandbanks (some 200 of which are inhabited), grouped in clusters, or atolls.

          Maldives
          Maldives
          The islands extend more than 510 miles (820 km) from north to south and 80 miles (130 km) from east to west. The northernmost atoll is about 370 miles (600 km) south-southwest of the Indian mainland, and the central area, including the capital island of Male (Male’), is about 400 miles (645 km) southwest of Sri Lanka."
        />
      </div>
    </div>
  );
}

export default Trip;
