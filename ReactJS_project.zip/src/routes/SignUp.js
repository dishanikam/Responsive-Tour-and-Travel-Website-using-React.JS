import AboutImg from "../assets/17.jpg";
import Footer from "../components/Footer";
import Hero from "../components/Hero";
import Navbar from "../components/Navbar";
import SignUpForm from "../components/SignUpForm";

function SignUp() {
  return (
    <>
      <Navbar />
      <Hero
        cName="hero-mid"
        heroImg={AboutImg}
        title="Contact"
        btnClass="hide"
      />
      <SignUpForm/>
      <Footer/>
    </>
  );
}

export default SignUp;